# potential for future development, if more tests are desired
test_that("multiplication works", {
  expect_equal(2 * 2, 4)
})
